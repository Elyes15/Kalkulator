package huhu.haha.kalkulator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    AdapterData adapterData;
    List<String> listData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView = findViewById(R.id.record);
        listData = new ArrayList<>();

        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapterData = new AdapterData(this, listData);
        recyclerView.setAdapter(adapterData);
        adapterData.notifyDataSetChanged();

        Button btnhitung = findViewById(R.id.btnHitung);
        EditText edt1 = (EditText) findViewById(R.id.Ed1);
        EditText edt2 = (EditText) findViewById(R.id.Ed2);
        TextView tvhasil = (TextView) findViewById(R.id.tvHasil);

        RadioButton rdtambah = (RadioButton) findViewById(R.id.rdTambah);
        RadioButton rdkurang = (RadioButton) findViewById(R.id.rdKurang);
        RadioButton rdkali = (RadioButton) findViewById(R.id.rdKali);
        RadioButton rdbagi = (RadioButton) findViewById(R.id.rdBagi);

        btnhitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double ed1, ed2, hasil = null;

                ed1 = Double.valueOf(edt1.getText().toString().trim());
                ed2 = Double.valueOf(edt2.getText().toString().trim());

                if (rdtambah.isChecked()){
                    hasil = ed1 + ed2;
                    String mhasil = String.valueOf(hasil);
                    tvhasil.setText(mhasil);
                    listData.add(ed1 + " " + "+" + " " + ed2 + " = " + mhasil);
                } else if(rdkurang.isChecked()){
                    hasil = ed1 - ed2;
                    String mhasil = String.valueOf(hasil);
                    tvhasil.setText(mhasil);
                    listData.add(ed1 + " " + "-" + " " + ed2 + " = " + mhasil);
                } else if(rdkali.isChecked()){
                    hasil = ed1 * ed2;
                    String mhasil = String.valueOf(hasil);
                    tvhasil.setText(mhasil);
                    listData.add(ed1 + " " + "x" + " " + ed2 + " = " + mhasil);
                } else if(rdbagi.isChecked()){
                    hasil = ed1 / ed2;
                    String mhasil = String.valueOf(hasil);
                    tvhasil.setText(mhasil);
                    listData.add(ed1 + " " + ":" + " " + ed2 + " = " + mhasil);
                }
            }
        });

    }
}